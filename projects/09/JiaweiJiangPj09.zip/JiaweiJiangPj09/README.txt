Student Name: Jiawei Jiang
Project#: 9

Compile file:
Compile “/scr/tank” with JackCompiler.sh and run it with VMEmulator.sh

Introduction:
This is a tank game. Player controls a tank to move and shoot monsters randomly showing up map.
Whenever you kill a monster, 100 score is gained.
ATTENTION!! Your tank is not strong enough to crash the monsters! When tank contacts with monsters, it will be broken! However, monsters are stupid and will only walk around in a small area. Do not be too afraid!

Instruction:
1.Use 4 arrows in keyboard to control your tank.
2.Press ‘z’ and ‘x’ to change the moving speed. It can be changed from 1 to 5(default:3).
3.Press ‘space’ in keyboard to shoot. You can keep pressing to shoot continuously. However, the new monsters will refresh in other places probablly.
4.Press ‘q’ to quit the game.