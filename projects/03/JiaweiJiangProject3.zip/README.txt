Student Name: Jiawei Jiang
Project#: 3

All 8.hdl files are completed and passed the script test.